package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class Video extends Activity {
	VideoView video;
	MediaController ctlr;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video);
		video = (VideoView) findViewById(R.id.videoView1);

		getWindow().setFormat(PixelFormat.TRANSLUCENT);
		try {
			Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.mbuzi);
			video.setVideoURI(uri);
			//video.setVideoPath("http://10.0.2.2/farm/mbuzi.mp4");
			ctlr = new MediaController(this);
			ctlr.setMediaPlayer(video);
			video.setMediaController(ctlr);
			video.requestFocus();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
