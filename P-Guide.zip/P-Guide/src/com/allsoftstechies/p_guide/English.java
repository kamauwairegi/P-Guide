package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class English extends Activity implements OnClickListener {
	ImageView profile, exercise,question,complication,diet,forum;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.english);
		profile = (ImageView) findViewById(R.id.imgProfile);
		exercise = (ImageView) findViewById(R.id.imgExercise);
		question = (ImageView) findViewById(R.id.imgQuestion);
		complication = (ImageView) findViewById(R.id.imgComplications);
		diet= (ImageView) findViewById(R.id.imgDiet);
		forum= (ImageView) findViewById(R.id.imgForum);

		profile.setOnClickListener(this);
		exercise.setOnClickListener(this);
		question.setOnClickListener(this);
		complication.setOnClickListener(this);
		diet.setOnClickListener(this);
		forum.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.imgProfile:
			Intent prof=new Intent(English.this,Profile.class);
			startActivity(prof);
			break;
		case R.id.imgExercise:
			Intent menu=new Intent(English.this,ExerciseList.class);
			startActivity(menu);
			break;
		case R.id.imgQuestion:
			Intent quiz=new Intent(English.this,QuizChoice.class);
			startActivity(quiz);
			break;
		case R.id.imgComplications:
			Intent comp=new Intent(English.this,ComplicationList.class);
			startActivity(comp);
			break;
		case R.id.imgDiet:
			Intent diet=new Intent(English.this,Diet.class);
			startActivity(diet);
			break;
		case R.id.imgForum:
			Intent forum=new Intent(English.this,ForumList.class);
			startActivity(forum);
			break;
		}

	}

}
