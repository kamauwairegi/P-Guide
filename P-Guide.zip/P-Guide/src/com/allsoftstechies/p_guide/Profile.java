package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends Activity implements OnClickListener {
	ImageView edit, view, add;
	TextView tv1, tv2, tv3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile);

		edit = (ImageView) findViewById(R.id.imgEdit);
		view = (ImageView) findViewById(R.id.imgView);
		add = (ImageView) findViewById(R.id.imgAdd);
		tv1 = (TextView) findViewById(R.id.tv1);
		tv2 = (TextView) findViewById(R.id.tv2);
		tv3 = (TextView) findViewById(R.id.tv3);
		tv1.setTextColor(Color.BLUE);
		tv2.setTextColor(Color.BLUE);
		tv3.setTextColor(Color.BLUE);

		edit.setOnClickListener(this);
		add.setOnClickListener(this);
		view.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.imgEdit:
			Intent edit = new Intent(Profile.this, Edit.class);
			startActivity(edit);
			break;
		case R.id.imgView:
			Intent view = new Intent(Profile.this, ViewEvent.class);
			startActivity(view);
			break;
		case R.id.imgAdd:
			Intent add= new Intent(Profile.this,Add.class);
			startActivity(add);
			break;
		}
	}

}
