/** Automatically generated file. DO NOT MODIFY */
package com.allsoftstechies.p_guide;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}