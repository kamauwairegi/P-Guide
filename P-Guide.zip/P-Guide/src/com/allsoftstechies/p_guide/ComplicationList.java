package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ComplicationList extends Activity implements OnItemClickListener {
	ListView complications;
	String list[] = null;
	static String selected_complication;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.complication_list);
		complications = (ListView) findViewById(R.id.lsComplications);
		
		new SetList().execute();//executing the async class
		
		complications.setOnItemClickListener(this);

	}

	public String[] getComplication()// let it be a boolean method
	{

		// beginning of insertion code
		String[] result = null;
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			/*
			 * nameValuePairs.add(new BasicNameValuePair("username", uname
			 * .getText().toString()));
			 */
			 nameValuePairs.add(new BasicNameValuePair("option", "compList"));
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/complicationlist.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString().split("#");
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}

		return result;
	}

	// Async class
	public class SetList extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(ComplicationList.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();

			// The code to be executed goes here...login the user
			try {
				list = getComplication();

			} catch (Exception e) {
				// TODO: handle exception
			}
			return null;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			complications.setAdapter(new ArrayAdapter<String>(
					ComplicationList.this, android.R.layout.simple_list_item_1,
					list));
		}

	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		try
		{
		selected_complication=complications.getItemAtPosition(arg2).toString().trim();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally
		{
		Intent ls=new Intent(ComplicationList.this,ComplicationDesc.class);
		startActivity(ls);
		}
	}
	public static String setSelectedItem()
	{
		return selected_complication;
	}

}
