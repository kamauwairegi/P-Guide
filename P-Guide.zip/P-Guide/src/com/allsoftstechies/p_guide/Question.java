package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Question extends Activity implements OnClickListener {
	TextView heading, title, desc;
	Button post, clear;
	EditText quiz, question;
	String p_id, g = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.question);
		heading = (TextView) findViewById(R.id.tvHead);
		title = (TextView) findViewById(R.id.tvTitle);
		desc = (TextView) findViewById(R.id.tvDesc);
		post = (Button) findViewById(R.id.btPost);
		clear = (Button) findViewById(R.id.btClear);
		quiz = (EditText) findViewById(R.id.edTitle);
		question = (EditText) findViewById(R.id.edQuestion);

		heading.setTextColor(Color.BLUE);
		title.setTextColor(Color.BLUE);
		desc.setTextColor(Color.BLUE);
		post.setTextColor(Color.BLUE);
		clear.setTextColor(Color.BLUE);

		post.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btPost:
			new QuizAsk().execute();
			break;

		}

	}

	public class QuizAsk extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(Question.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Posting your question...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String answer = null;
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();

			// The code to post question here
			try {
				g = question();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			return answer;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			String decision = g.toString();
			// decision.toString().equalsIgnoreCase("success")
			if (decision.contains("success")) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						Question.this);
				builder.setTitle("SUCCESS");
				builder.setMessage("Your question successfully posted. We will get back to you...Thank you! ");
				builder.setCancelable(true);
				builder.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert1 = builder.create();
				alert1.show();
				quiz.setText(null);
				question.setText(null);
			} else {
				AlertDialog.Builder builder1 = new AlertDialog.Builder(
						Question.this);
				builder1.setTitle("NOT SUCCESSFUL");
				builder1.setMessage("Sorry,there was an error during the posting process...Please try again.");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();
				quiz.setText(null);
				question.setText(null);
			}
		}
	}

	public String question()// let it be a boolean method
	{

		// beginning of insertion code
		String result = "";
		p_id = Login.setId();
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			nameValuePairs.add(new BasicNameValuePair("title", quiz.getText()
					.toString()));
			nameValuePairs.add(new BasicNameValuePair("question", question
					.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("p_id", p_id));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/askquestion.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString();
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}

		return result;
	}

}
