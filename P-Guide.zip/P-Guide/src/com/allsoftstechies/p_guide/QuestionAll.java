package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class QuestionAll extends Activity implements OnItemClickListener{
	ListView list;
	static String item;
	String p_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.complication_list);
		list=(ListView)findViewById(R.id.lsComplications);
		
		list.setOnItemClickListener(this);

		String[] result1 =null;
		p_id=Login.setId();
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>();
		try {
			nameValuePairs1.add(new BasicNameValuePair("option", "all"));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://10.0.2.2/preg_guide/all_questions.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result1 = sb.toString().split("#");
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result:" + e.toString());
		}
		finally
		{
			list.setAdapter(new ArrayAdapter<String>(QuestionAll.this, android.R.layout.simple_list_item_1, result1));
		}

		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		try
		{
		item=list.getItemAtPosition(arg2).toString().trim();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally
		{
		Intent ls=new Intent(QuestionAll.this,AllQuestions.class);
		startActivity(ls);
		}
		
	}
	public static String setQuestion()
	{
		return item;
	}

}
