package com.allsoftstechies.p_guide;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity /* implements OnClickListener */{
	// TextView english, kiswahili;
	protected int _splashTime = 3000;
	ProgressBar bar;

	boolean isRunning = false;

	private Thread splashTread;
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			bar.incrementProgressBy(34);
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// english = (TextView) findViewById(R.id.txtEng);
		// kiswahili = (TextView) findViewById(R.id.txtSwa);
		bar = (ProgressBar) findViewById(R.id.progressBar1);

		final MainActivity sPlashScreen = this;

		// thread for displaying the SplashScreen
		splashTread = new Thread() {
			@Override
			public void run() {
				try {
					synchronized (this) {
						wait(_splashTime);
					}

				} catch (InterruptedException e) {
				} finally {
					finish();

					Intent i = new Intent();
					i.setClass(sPlashScreen, Login.class);
					startActivity(i);

					// stop();
				}
			}
		};

		splashTread.start();
		// english.setOnClickListener(this);
		// kiswahili.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/*
	 * @Override public void onClick(View v) { // TODO Auto-generated method
	 * stub switch (v.getId()) { case R.id.txtEng: Intent eng = new
	 * Intent("com.allsoftstechies.ENGLISH"); startActivity(eng); break; case
	 * R.id.txtSwa: Intent swa = new Intent("com.allsoftstechies.KISWAHILI");
	 * startActivity(swa); break; }
	 * 
	 * }
	 */
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			synchronized (splashTread) {
				splashTread.notifyAll();
			}
		}
		return true;
	}

	public void onStart() {
		super.onStart();
		bar.setProgress(0);
		Thread background = new Thread(new Runnable() {
			public void run() {
				try {
					for (int i = 0; i < 20 && isRunning; i++) {
						Thread.sleep(1000);
						handler.sendMessage(handler.obtainMessage());
					}
				} catch (Throwable t) {
					// just end the background thread
				}
			}
		});
		isRunning = true;
		background.start();
	}

	public void onStop() {
		super.onStop();
		isRunning = false;
	}
}
