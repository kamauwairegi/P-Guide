package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ComplicationDesc extends Activity implements OnItemClickListener {
	ListView complicationsDesc;
	String list[] = { "Introduction", "Signs and Symptoms", "Causes",
			"Side Effects", "Prevention and Cure", "Related audio clip",
			"Related Video clip" };
	static String selected_desc;
	static int index;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.complication_list);
		complicationsDesc = (ListView) findViewById(R.id.lsComplications);

		complicationsDesc.setAdapter(new ArrayAdapter<String>(
				ComplicationDesc.this, android.R.layout.simple_list_item_1,
				list));

		complicationsDesc.setOnItemClickListener(this);

	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		try {
			selected_desc= complicationsDesc.getItemAtPosition(arg2)
					.toString().trim();
			index=arg2;
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			Intent ls = new Intent(ComplicationDesc.this,
					ComplicationDetails.class);
			startActivity(ls);
		}
	}

	public static String setSelectedDesc() {
		return selected_desc;
	}
	public static int setSelectedIndex() {
		return index;
	}

}
