package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Add extends Activity implements OnClickListener{
	TextView event,venue,date;
	Button add;
	EditText edEvent,edVenue;
	DatePicker datePick;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.event);
		
		event=(TextView)findViewById(R.id.tvEvent);
		venue=(TextView)findViewById(R.id.tvVenue);
		date=(TextView)findViewById(R.id.tvDate);
		datePick=(DatePicker)findViewById(R.id.dateEvent);
		edEvent=(EditText)findViewById(R.id.edEvent);
		edVenue=(EditText)findViewById(R.id.edVenue);
		add=(Button)findViewById(R.id.btAddEvent);
		
		event.setTextColor(Color.BLUE);
		venue.setTextColor(Color.BLUE);
		date.setTextColor(Color.BLUE);
		add.setTextColor(Color.BLUE);
		
		add.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.btAddEvent:
			try
			{
			String evn=edEvent.getText().toString();
			String ven=edVenue.getText().toString();
			String dt=datePick.getDayOfMonth()+"/"+datePick.getMonth()+"/"+datePick.getYear();
			SQLiteDB db=new SQLiteDB(Add.this);
			db.open();
			db.addEvent(evn,ven,dt);
			db.close();
			
			}catch (Exception e) {
				// TODO: handle exception
			}
			finally
			{
				Time now=new Time();
				edEvent.setText(null);
				edVenue.setText(null);
				datePick.updateDate(now.year, now.month, now.monthDay);
			}
			break;		
		}
	}

}
