package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Edit extends Activity implements OnClickListener {
	TextView name, username, password, password1, phone, email;
	EditText pname, pusername, pemail, pphone, ppassword, ppassword1;
	Button update;
	String p_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		username = (TextView) findViewById(R.id.txtUsername);
		password = (TextView) findViewById(R.id.txtPassword);
		password1 = (TextView) findViewById(R.id.txtPassword1);
		name = (TextView) findViewById(R.id.txtName);
		phone = (TextView) findViewById(R.id.txtPhone);
		email = (TextView) findViewById(R.id.txtEmail);

		pusername = (EditText) findViewById(R.id.edUsername);
		ppassword = (EditText) findViewById(R.id.edPassword);
		ppassword1 = (EditText) findViewById(R.id.edPassword1);
		pname = (EditText) findViewById(R.id.edName);
		pphone = (EditText) findViewById(R.id.edPhone);
		pemail = (EditText) findViewById(R.id.edemail);

		name.setTextColor(Color.BLUE);
		username.setTextColor(Color.BLUE);
		password.setTextColor(Color.BLUE);
		password1.setTextColor(Color.BLUE);
		phone.setTextColor(Color.BLUE);
		email.setTextColor(Color.BLUE);
		
		p_id=Login.setId();

		update = (Button) findViewById(R.id.btRegister);
		update.setText("Update");
		update.setTextColor(Color.BLUE);

		pname.setEnabled(false);
		pname.setFocusableInTouchMode(false);

		update.setOnClickListener(this);
		
		getProfile();

	}

	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btRegister:
			UpdateProf();
			Toast.makeText(getApplicationContext(),
					"Profile successfully updated", Toast.LENGTH_LONG).show();
			pusername.setText("");
			pphone.setText("");
			pemail.setText("");
			ppassword.setText("");
			ppassword1.setText("");
			break;
		}
	}

	// query profile
	public void getProfile()// let it be a boolean method
	{

		String result1 = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>();
		try {
			nameValuePairs1.add(new BasicNameValuePair("p_id", p_id));
			nameValuePairs1.add(new BasicNameValuePair("option", "edit"));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/profile.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result1 = sb.toString();
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result:" + e.toString());
		}

		// parse json data

		try {
			JSONArray jArray = new JSONArray(result1);
			for (int j = 0; j < jArray.length(); j++) {
				JSONObject json_data = jArray.getJSONObject(j);
				pusername.setText(json_data.getString("username"));
				pname.setText(json_data.getString("name"));
				pphone.setText(json_data.getString("phone"));
				pemail.setText(json_data.getString("email"));

			}
			// .setAdapter(adapter);
		} catch (JSONException e) {
			Log.e("log_tag", "Error parsing data " + e.toString());

		}
		
		
	}
	
	// update profile
	public void UpdateProf()
	{

		String result1 = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>();
		try {
			nameValuePairs1.add(new BasicNameValuePair("p_id", p_id));
			nameValuePairs1.add(new BasicNameValuePair("password", ppassword.getText().toString()));
			nameValuePairs1.add(new BasicNameValuePair("username", pusername.getText().toString()));
			nameValuePairs1.add(new BasicNameValuePair("phone",  pphone.getText().toString()));
			nameValuePairs1.add(new BasicNameValuePair("email",  pemail.getText().toString()));
			nameValuePairs1.add(new BasicNameValuePair("option", "update"));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/profile.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result1 = sb.toString();
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result:" + e.toString());
		}
	}

}
