package com.allsoftstechies.p_guide;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDB {
	private static final String DB_NAME = "preg_guide";
	private static final String DB_TABLE = "event_table";
	private static final int DB_VERSION = 1;

	public static final String ID = "id";
	public static final String EVENT = "event";
	public static final String VENUE = "venue";
	public static final String DATE = "date";

	private DBHelper ourHelper;
	private final Context ourContext;
	private SQLiteDatabase ourDatabase;

	public static class DBHelper extends SQLiteOpenHelper {

		public DBHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + DB_TABLE + " (" + ID
					+ " INTEGER PRIMARY KEY AUTOINCREMENT, " + EVENT
					+ " TEXT NOT NULL, " + VENUE + " TEXT NOT NULL, " + DATE
					+ " TEXT NOT NULL);");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DB_TABLE);
			onCreate(db);
		}

	}

	public SQLiteDB(Context c) {
		ourContext = c;
	}

	public SQLiteDB open() throws SQLiteException {
		ourHelper = new DBHelper(ourContext);
		ourDatabase = ourHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		ourHelper.close();
	}

	public long addEvent(String evn, String ven, String dt) {
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(EVENT, evn);
		cv.put(VENUE, ven);
		cv.put(DATE, dt);
		return ourDatabase.insert(DB_TABLE, null, cv);

	}

	public String getData() {
		// TODO Auto-generated method stub
		String[] columns = new String[] { ID, EVENT, VENUE, DATE };
		Cursor c = ourDatabase.query(DB_TABLE, columns, null, null, null, null,
				null);

		String result = "";

		int indexID = c.getColumnIndex(ID);
		int indexEvent = c.getColumnIndex(EVENT);
		int indexVenue = c.getColumnIndex(VENUE);
		int indexDate = c.getColumnIndex(DATE);
		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			result = result + "<b>ID:</b> " + c.getString(indexID)
					+ "<br><b>Event:</b> " + c.getString(indexEvent)
					+ "<br><b>Venue:</b> " + c.getString(indexVenue)+"<br><b>Date</b> "+c.getString(indexDate)+"<br><br>";
		}

		return result;
	}
}
