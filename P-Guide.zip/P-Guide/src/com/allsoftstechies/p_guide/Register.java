package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends Activity implements OnClickListener {
	TextView name, username, password,password1, phone, email;
	Button register;
	EditText pname, pusername, pemail, pphone, ppassword, ppassword1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		username = (TextView) findViewById(R.id.txtUsername);
		password = (TextView) findViewById(R.id.txtPassword);
		password1 = (TextView) findViewById(R.id.txtPassword1);
		name = (TextView) findViewById(R.id.txtName);
		phone = (TextView) findViewById(R.id.txtPhone);
		email = (TextView) findViewById(R.id.txtEmail);

		pusername = (EditText) findViewById(R.id.edUsername);
		ppassword = (EditText) findViewById(R.id.edPassword);
		ppassword1 = (EditText) findViewById(R.id.edPassword1);
		pname = (EditText) findViewById(R.id.edName);
		pphone = (EditText) findViewById(R.id.edPhone);
		pemail = (EditText) findViewById(R.id.edemail);

		register = (Button) findViewById(R.id.btRegister);

		name.setTextColor(Color.BLUE);
		username.setTextColor(Color.BLUE);
		password.setTextColor(Color.BLUE);
		password1.setTextColor(Color.BLUE);
		phone.setTextColor(Color.BLUE);
		email.setTextColor(Color.BLUE);
		register.setTextColor(Color.BLUE);

		register.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btRegister:
			if (pname.getText().toString().equals("")
					|| ppassword.getText().toString().equals("")
					|| pphone.getText().toString().equals("")
					|| ppassword1.getText().toString().equals("")
					|| pemail.getText().toString().equals("")
					|| pusername.getText().toString().equals("")) {
				AlertDialog.Builder builder1 = new AlertDialog.Builder(
						Register.this);
				builder1.setTitle("EMPTY FIELDS");
				builder1.setMessage("Please fill in all the required fields");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();

			} else if (!(ppassword.getText().toString().equals(ppassword1
					.getText().toString()))) {
				AlertDialog.Builder builder1 = new AlertDialog.Builder(
						Register.this);
				builder1.setTitle("PASSWORD MISMATCH");
				builder1.setMessage("Passwords do not match");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();

			} else {
				new Reg().execute();
				break;
			}
		}

	}

	public class Reg extends AsyncTask<String, Integer, String> {
		int i;
		String g = "";
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(Register.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Accessing the server...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();
			// registration process
			try {
				g = registration();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			return null;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			String decision = g.toString();
			// decision.toString().equalsIgnoreCase("success")
			if (decision.contains("success")) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						Register.this);
				builder.setTitle("SUCCESS");
				builder.setMessage("Registration process seccessful.Please login now...Thank you! ");
				builder.setCancelable(true);
				builder.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert1 = builder.create();
				alert1.show();
				pname.setText(null);
				pusername.setText(null);
				pemail.setText(null);
				pphone.setText(null);
				ppassword.setText(null);
				ppassword1.setText(null);
			} else {
				AlertDialog.Builder builder1 = new AlertDialog.Builder(
						Register.this);
				builder1.setTitle("NOT SUCCESSFUL");
				builder1.setMessage("There was an error during your registration process. Please try again ");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();
				pname.setText(null);
				pusername.setText(null);
				pemail.setText(null);
				pphone.setText(null);
				ppassword.setText(null);
				ppassword1.setText(null);

			}
		}

	}

	public String registration()// let it be a boolean method
	{

		// beginning of insertion code
		String result = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			nameValuePairs.add(new BasicNameValuePair("username", pusername
					.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("password", ppassword
					.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("phone", pphone.getText()
					.toString()));
			nameValuePairs.add(new BasicNameValuePair("email", pemail.getText()
					.toString()));
			nameValuePairs.add(new BasicNameValuePair("name", pname.getText()
					.toString()));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/register.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString();
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}

		return result;
	}

}
