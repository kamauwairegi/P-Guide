package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;

public class ViewEvent extends Activity{
	TextView title,content;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.question_display);
		title=(TextView)findViewById(R.id.tvQTitle);
		content=(TextView)findViewById(R.id.tvQContent);
		
		title.setTextColor(Color.BLUE);
		title.setText("My Events");
		
		SQLiteDB info=new SQLiteDB(this);
		info.open();		
		String query=info.getData();
		info.close();
		content.setText(Html.fromHtml(query));
	}

}
