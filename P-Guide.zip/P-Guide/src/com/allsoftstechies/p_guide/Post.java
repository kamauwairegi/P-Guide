package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Post extends Activity implements OnClickListener{
	Button post;
	EditText edPost;
	TextView tvPost;
	int f_id;
	String p_id;
	String posted;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.post);
		post=(Button)findViewById(R.id.btnPost);
		edPost=(EditText)findViewById(R.id.edPost);
		tvPost=(TextView)findViewById(R.id.tvPost);
		
		post.setTextColor(Color.BLUE);
		tvPost.setTextColor(Color.BLUE);
		
		posted=Forum.getPost();
		 f_id = ForumList.setFId();
		 p_id=Login.setId();
		
		post.setOnClickListener(this);
	}
	
	public class Topic extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(Post.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Posting new topic...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String answer = null;
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();

			// The code to be executed goes here...login the user
			try
			{
				newTopic();
			}catch (Exception e) {
				// TODO: handle exception
			}

			return answer;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			try
			{
			edPost.setText(null);
			Toast.makeText(getApplicationContext(), "Topic posted", Toast.LENGTH_LONG).show();
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			finally
			{
				Intent inte=new Intent(Post.this,ForumList.class);
				startActivity(inte);
			}
		}

	}
	
	public class Participate extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(Post.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Posting your comment...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String answer = null;
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();

			// The code to be executed goes here...login the user
			try
			{
			newComment();	
			}catch (Exception e) {
				// TODO: handle exception
			}

			return answer;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			try
			{
			edPost.setText(null);
			Toast.makeText(getApplicationContext(), "Comment Posted", Toast.LENGTH_LONG).show();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			finally
			{
				Intent inte=new Intent(Post.this,Forum.class);
				startActivity(inte);
			}
		}

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.btnPost:
			if(posted.toString().equals("participate"))
			{
				new Participate().execute();
			}
			else if(posted.toString().equals("post"))
			{
				new Topic().execute();
			}
			break;
		}
		
	}
	public void newTopic()
	{
		String result = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			nameValuePairs.add(new BasicNameValuePair("title", edPost.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("option", "topic"));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/post.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString();
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}
	}
	
	public void newComment()
	{
		String result = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			nameValuePairs.add(new BasicNameValuePair("comment", edPost.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("option", "comment"));
			nameValuePairs.add(new BasicNameValuePair("f_id", ""+f_id));
			nameValuePairs.add(new BasicNameValuePair("p_id", ""+p_id));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/post.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString();
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}
	}
}
