package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.R.string;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract.Profile;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity implements OnClickListener {
	TextView prof, username, password,lost;
	Button login, register;
	EditText uname, pword;
	boolean registered;
	static String p_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		prof = (TextView) findViewById(R.id.txtProf);
		username = (TextView) findViewById(R.id.txtUsername);
		password = (TextView) findViewById(R.id.txtPassword);
		lost = (TextView) findViewById(R.id.tvLost);
		pword = (EditText) findViewById(R.id.etPassword);
		uname = (EditText) findViewById(R.id.etUsername);

		login = (Button) findViewById(R.id.btLogin);
		register = (Button) findViewById(R.id.btRegister);

		prof.setTextColor(Color.BLUE);
		username.setTextColor(Color.BLUE);
		password.setTextColor(Color.BLUE);
		login.setTextColor(Color.BLUE);
		register.setTextColor(Color.BLUE);
		lost.setTextColor(Color.BLUE);

		register.setOnClickListener(this);
		login.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.btRegister:
			// setContentView(R.layout.login);
			Intent reg = new Intent("com.allsoftstechies.REGISTER");
			startActivity(reg);
			break;
		case R.id.btLogin:
			if (uname.getText().toString().equals(null)
					|| uname.getText().toString().equals("")
					|| pword.getText().toString().equals(null)
					|| pword.getText().toString().equals("")) {
				AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
				builder1.setTitle("EMPTY FIELDS");
				builder1.setMessage("Please provide your username and password");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();

			} else {
				new Log().execute();
			}
			break;
		}

	}

	public class Log extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(Login.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Authenticating...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String answer = null;
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//dialog.dismiss();

			// The code to be executed goes here...login the user
			try {
				registered = signIn();
				if (registered == true) {
					answer = "true";
				} else {
					answer = "false";
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				Toast.makeText(getApplicationContext(), "" + e,
						Toast.LENGTH_LONG).show();
			}
			return answer;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			try
			{
			String g = doInBackground();
			if (g.equalsIgnoreCase("true")) {
				uname.setText(null);
				pword.setText(null);
				Intent log = new Intent(Login.this, English.class);
				startActivity(log);
			} else {
				uname.setText(null);
				pword.setText(null);
				AlertDialog.Builder builder1 = new AlertDialog.Builder(Login.this);
				builder1.setTitle("NOT MEMBER");
				builder1.setMessage("Please register with us to gain access");
				builder1.setCancelable(true);
				builder1.setNeutralButton(android.R.string.ok,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int id) {

								dialog.cancel();
							}
						});

				AlertDialog alert11 = builder1.create();
				alert11.show();
			}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			finally
			{
				 if (this.dialog.isShowing()) {
				        this.dialog.dismiss();
				     }
			}
			
			}
		

	}

	public boolean signIn()// let it be a boolean method
	{
		boolean returned = false;
		// beginning of insertion code
		String result = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		try {
			nameValuePairs.add(new BasicNameValuePair("username", uname
					.getText().toString()));
			nameValuePairs.add(new BasicNameValuePair("password", pword
					.getText().toString()));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://10.0.2.2/preg_guide/login.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result = sb.toString();
		} catch (Exception e) {
			// Log.e("log_tag", "Error converting result " + e.toString());
		}

		// parse json data

		try {
			JSONArray jArray = new JSONArray(result);
			for (int j = 0; j < jArray.length(); j++) {
				JSONObject json_data = jArray.getJSONObject(j);
				
					p_id=json_data.getString("p_id");
					returned = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returned;
	}
	public static String setId()
	{
		return p_id;
	}

}
