package com.allsoftstechies.p_guide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class QuizChoice extends Activity implements OnClickListener {
	ImageView ask,myQuestions,all;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.questionchoice);
		ask=(ImageView)findViewById(R.id.imgAsk);
		myQuestions=(ImageView)findViewById(R.id.imgMyQuiz);
		all=(ImageView)findViewById(R.id.imgAll);
		
		ask.setOnClickListener(this);
		myQuestions.setOnClickListener(this);
		all.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.imgAsk:
			Intent as=new Intent(QuizChoice.this,Question.class);
			startActivity(as);
			break;
		case R.id.imgMyQuiz:
			Intent my=new Intent(QuizChoice.this,QuestionList.class);
			startActivity(my);
			break;
		case R.id.imgAll:
			Intent all=new Intent(QuizChoice.this,QuestionAll.class);
			startActivity(all);
			break;
		}
		
	}

}
