package com.allsoftstechies.p_guide;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.TextView;

public class ComplicationDetails extends Activity {
	TextView title, content;
	String complication,heading,s;
	int index;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.question_display);

		title = (TextView) findViewById(R.id.tvQTitle);
		content = (TextView) findViewById(R.id.tvQContent);
		
		heading=ComplicationDesc.setSelectedDesc();
		index=ComplicationDesc.setSelectedIndex();

		title.setText(Html.fromHtml("<u><b>"+heading+"</b></u>"));
		title.setTextColor(Color.BLUE);
		
		complication=ComplicationList.setSelectedItem();

		new CompDetail().execute();
	}
	
	public class CompDetail extends AsyncTask<String, Integer, String> {
		int i;
		ProgressDialog dialog;

		protected void onPreExecute() {
			/*
			 * f="Am doing it"; Toast.makeText(getApplicationContext(),
			 * "Starting",Toast.LENGTH_LONG).show();
			 */
			dialog = new ProgressDialog(ComplicationDetails.this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setTitle("Loading...");
			dialog.setMessage("Please wait...Accessing the server...");
			dialog.setMax(200);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String answer = null;
			for (i = 1; i < 20; i++) {
				publishProgress(5);
				try {
					Thread.sleep(88);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			dialog.dismiss();

			// The code to be executed goes here...login the user
			try
			{
			s=getDetails().toString();
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			return answer;
		}

		protected void onProgressUpdate(Integer... progress) {
			dialog.incrementProgressBy(progress[0]);
		}

		protected void onPostExecute(String result) {
			content.setText(Html.fromHtml(s));
		}

	}
	
	public StringBuilder getDetails()
	{
		StringBuilder build = new StringBuilder();

		String result1 = "";
		// the year data to send
		ArrayList<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>();
		try {
			nameValuePairs1.add(new BasicNameValuePair("name", complication));
			nameValuePairs1.add(new BasicNameValuePair("option", "details"));
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost("http://10.0.2.2/preg_guide/complicationlist.php");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs1));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();

			result1 = sb.toString();
		} catch (Exception e) {
			Log.e("log_tag", "Error converting result:" + e.toString());
		}

		// parse json data

		try {
			JSONArray jArray = new JSONArray(result1);
			for (int j = 0; j < jArray.length(); j++) {
				JSONObject json_data = jArray.getJSONObject(j);
				if(index==0)
				{
				build.append(json_data.getString("description"));
				}
				else if(index==1)
				{
					build.append(json_data.getString("signs"));
				}
				else if(index==2)
				{
					build.append(json_data.getString("cause"));
				}
				else if(index==3)
				{
					build.append(json_data.getString("sideeffects"));
				}
				else if(index==4)
				{
					build.append(json_data.getString("prevention"));
				}
				else if(index==5)
				{
					
				}
				else if(index==6)
				{
					//code to play video here
					Intent vid=new Intent(ComplicationDetails.this,Video.class);
					startActivity(vid);
				}

			}
			// .setAdapter(adapter);
		} catch (JSONException e) {
			Log.e("log_tag", "Error parsing data " + e.toString());

		} 
		return build;
	}

}
